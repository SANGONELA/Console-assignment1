﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

public class User
{
    public string Name { get; set; } // automatic property
    public string FavoriteTopic { get; set; }

    public class CyberBot
    {
        public void Respond(string input)
        {
            string lower = input.ToLower().Trim(); // string manipulation

            if (string.IsNullOrWhiteSpace(lower))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Bot: I didn't quite understand that. Could you rephrase?");
                Console.ResetColor();
                return;
            }

            if (lower.Contains("how are you"))
                Console.WriteLine("Bot: I'm secure and running! How can I help you stay safe today?");
            else if (lower.Contains("purpose") || lower.Contains("what do you do"))
                Console.WriteLine("Bot: My purpose is to teach you about cybersecurity - passwords, phishing, and safe browsing.");
            else if (lower.Contains("password"))
                Console.WriteLine("Bot: Use long, unique passwords! 12+ chars, mix of letters, numbers, symbols. Never reuse!");
            else if (lower.Contains("phishing"))
                Console.WriteLine("Bot: Phishing is fake emails/links that steal your data. Always check the sender email!");
            else if (lower.Contains("safe browsing") || lower.Contains("browsing"))
                Console.WriteLine("Bot: Use HTTPS sites, don't click pop-ups, keep your browser updated.");
            else if (lower.Contains("what can i ask"))
                Console.WriteLine("Bot: You can ask me about password safety, phishing, and safe browsing.");
            else
                Console.WriteLine("Bot: I didn't quite understand that. Could you rephrase? Try asking about passwords or phishing.");
        }

class Program
        {
            static void Main()
            {
                // 1. VOICE GREETING - Task 1
                PlayGreeting();

                // 2. ASCII IMAGE - Task 2
                ShowAsciiArt();

                // 3. TEXT GREETING + USER INTERACTION - Task 3
                User user = new User();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\n==========================================");
                Console.WriteLine(" Welcome to Cybersecurity Awareness Bot");
                Console.WriteLine("==========================================");
                Console.ResetColor();

                Console.Write("Bot: What is your name? ");
                string nameInput = Console.ReadLine();

                // Input validation + string manipulation
                while (string.IsNullOrWhiteSpace(nameInput))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("Bot: Name cannot be empty. Please enter your name: ");
                    Console.ResetColor();
                    nameInput = Console.ReadLine();
                }
                user.Name = nameInput.Trim(); // string manipulation

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"\nBot: Hello {user.Name}! It's great to meet you. I'm here to help you stay safe online.");
                Console.ResetColor();

                // 4 & 5. RESPONSE SYSTEM + LOOP
                CyberBot bot = new CyberBot();
                Console.WriteLine("\nBot: Ask me about passwords, phishing, or safe browsing. Type 'exit' to quit.\n");

                while (true)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.Write($"{user.Name}: ");
                    Console.ResetColor();
                    string question = Console.ReadLine();

                    if (question.ToLower() == "exit")
                        break;

                    bot.Respond(question);
                    Console.WriteLine();
                }
            }

            static void PlayGreeting()
            {
                try
                {
                    SoundPlayer player = new SoundPlayer("greeting.wav");
                    player.PlaySync();
                }
                catch
                {
                    Console.WriteLine("[Audio file not found - skipping voice greeting]");
                }
            }

            static void ShowAsciiArt()
            {
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine(@"
____ _ _ _
/ ___| _ _| |__ ___ _ __ ___ ___| | |_ _ _ __
| | | | | | | '_ \ / _ \ '__/ __|/ _ \ | | | | | '_ \
| |__| |_| | |_) | __/ | \__ \ __/ | | |_| | |_) |
\____\__, |_.__/ \___|_| |___/\___|_|_|\__,_|.__/
|___/ |_|
LOCK YOUR DIGITAL WORLD
");
                Console.ResetColor();
            }
        }
    }
    }

